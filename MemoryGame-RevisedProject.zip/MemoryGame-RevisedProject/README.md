# MyMemoryGameUdacity
CREATING A MEMORY GAME BY USING JAVASCRIPT

# introduction:
Memory has long been a favorite game for all generations. It is easy to play,requires observation, 
concentration and a good memory to win. 

# how it works:
the game contain 16 cards with different images.each card has a pair.
the player need to match two pairs together to win the game

# used toolss & software:
HTML,CSSS,JAVASCRIPT,jQuery with a visual code studio.

# ressourses used:
udacity.com
w3school.com
getbootstrap.com
modal youtube tutorials

# need help:
you can reach me in my e-mail:
sma_ez@hotmail.com
